# ADIS RO Capture PWA
Upload this folder's contents to your GitHub repository.

## Enable GitHub Pages
1. Go to your repository Settings > Pages
2. Under 'Source', choose the `main` branch and `/root` folder (or `/docs` if used)
3. Save – your site will be available at:
   https://yourusername.github.io/your-repo-name/

Open it in Safari and choose 'Add to Home Screen' to use it like a mobile app.
